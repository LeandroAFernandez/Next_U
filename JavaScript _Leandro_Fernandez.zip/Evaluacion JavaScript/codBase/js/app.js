var num = ["0","1","2","3","4","5","6","7","8","9"]

for (let i = 0; i < num.length; i++) {
    document.getElementById(num[i]).addEventListener('click', checkDisplay);  
}

function checkDisplay(evento){
    largo = document.getElementById('display').textContent.length
    if (largo <= 7){
        if (resultado.textContent == "0") 
        { resultado.textContent = evento.target.id }
        else 
        { resultado.textContent = resultado.textContent + evento.target.id};
    }
    else if (largo >= 7)
    {
    
    }
}

document.getElementById("punto").addEventListener('click', function(){ 
    largo = document.getElementById('display').textContent.length
    if (largo <= 7){
         if (resultado.textContent.includes(".")) {

         }
         else
         {resultado.textContent = resultado.textContent + "."}
    }
    else if (largo >= 7)
    {}
    })

document.getElementById("sign").addEventListener('click', signoNum)
    function signoNum() {
        
        if (resultado.textContent == 0) { 
            resultado.textContent = resultado.textContent;
        }
        else if (resultado.textContent.includes("-")){ 
            resultado.textContent = Number(resultado.textContent) * -1;
        }
        else
        {
            resultado.textContent = "-" + resultado.textContent;
        }
    }
var resultado = document.getElementById('display')
var numUno = ""
var numDos = ""
var tipoOp = ""

function limpiar(){
    resultado.textContent = "";
    
}

function OnC(){
    resultado.textContent = "0";
    numUno = ""; 
    numDos = "";
    tipoOp = "";
}



function resolver(numero1,numero2){
    var total = 0;
        switch (tipoOp) {
            case "suma":
                total = numero1 + numero2;
                break;
            case "resta":
                total = numero1 - numero2;
                break;
            case "dvdr":
                if (numDos == 0){
                alert("No es posible dividir por 0!");
                OnC();
                }
                else{
                total = numero1 / numero2;
                };   
                break;
            case "mltplc":
                total = numero1 * numero2;
                break;
                default:
                break;
        };
       
        document.getElementById('display').innerHTML = total.toString().slice(0,8);
}



var Calculadora = {
       
    init: function () {
        document.getElementById("por").onclick = this.multiplicar;
        document.getElementById("dividido").onclick = this.dividir;
        document.getElementById("menos").onclick = this.restar;
        document.getElementById("mas").onclick = this.sumar;
        document.getElementById("on").onclick = OnC;
        document.getElementById("igual").onclick = this.igual;
    },   
    sumar: function(event){
        tipoOp = "suma";
        numUno = resultado.textContent;
        limpiar();
    },
    
    restar: function(){
        tipoOp = "resta";
        numUno = resultado.textContent;
        limpiar();
        
    },
    
    dividir: function(){
        tipoOp = "dvdr";
        numUno = resultado.textContent;
        limpiar();
    },

    multiplicar: function(){
        tipoOp = "mltplc";
        numUno = resultado.textContent;
        limpiar();
    },
    
    igual: function(){
        numDos = resultado.textContent;
        resolver(parseFloat(numUno),parseFloat(numDos));
    },
   

}

Calculadora.init()
